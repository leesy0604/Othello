package sample;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.*;

public class Controller implements Initializable {
    @FXML
    public AnchorPane Rule;
    public Label label_rule;
    public ImageView pan;   //바둑판
    public AnchorPane gamePane;
    public TextArea gameRule;
    public Label label_turn;
    public Label label_black;
    public Label label_white;
    public ImageView black;
    public ImageView white;
    public Image black_image;
    public Image white_image;

    public int color[][] = new int[8][8];//비어있으면 0, 흰돌 1, 검은돌 2


    Vector<Stone> attachedstone = null;

    public boolean turn = true;
    public int black_cnt = 0;
    public int white_cnt = 0;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        black = new ImageView("black.jpg");
        white = new ImageView("white.jpg");
        black_image = new Image("black.jpg", 50, 50, false, false);
        white_image = new Image("white.jpg", 50, 50, false, false);

        attachedstone = new Vector<>();

        addStone(150, 200, true);
        addStone(150, 150, false);
        addStone(200, 150, true);
        addStone(200, 200, false);


        color[3][3] = 1;
        color[3][4] = 2;
        color[4][3] = 2;
        color[4][4] = 1;

//        for(int i=0; i<8; i++){
//            for(int j=0; j<8; j++){
//                System.out.print(color[i][j]);
//            }
//            System.out.println();
//        }


//            for(int i=0; i<attachedstone.size(); i++){
//                if(4==attachedstone.get(i).getX()/50)
//                    System.out.println(i+"있음");
//
//                else
//                    System.out.println(i+"없음");
//        }
//        list.get(index).getx();

        label_rule.setOnMouseClicked(event -> {
            RulePrint Print = new RulePrint();
            Print.start();
        });

        pan.setOnMouseClicked(event -> {
            addStone((int) event.getX(), (int) event.getY(), turn);
            check((int) event.getX(), (int) event.getY(), turn);
            if (turn) {
                label_turn.setText("흑돌 차례");
            } else {
                label_turn.setText("흰돌 차례");
            }
            turn = !turn;

            label_black.setText("흑돌 : " + black_cnt + "개");
            label_white.setText("흰돌 : " + white_cnt + "개");

        });


    }

    public class Stone {
        int x;
        int y;
        boolean turn;
        ImageView imageview;//black true white false

        public Stone(int x, int y, boolean turn, ImageView imageview) {
            this.x = x;
            this.y = y;
            this.turn = turn;
            this.imageview = imageview;
        }

        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }


        public boolean isTurn() {
            return turn;
        }

        public void setTurn(boolean turn) {
            this.turn = turn;
        }

        public ImageView getImageview() {
            return imageview;
        }

        public void setImageview(ImageView imageview) {
            this.imageview = imageview;
        }
    }//x, y, turn, imageview


    public void addStone(int x, int y, boolean turn) {
        ImageView i = new ImageView();
        i.setX((x / 50) * 50 + 14);
        i.setY((y / 50) * 50 + 14);
        if (turn) {
            i.setImage(new Image("black.jpg", 50, 50, false, false));
            color[x / 50][y / 50] = 2;
            black_cnt++;
        } else {
            i.setImage(new Image("white.jpg", 50, 50, false, false));
            color[x / 50][y / 50] = 1;
            white_cnt++;
        }

        Stone stone = new Stone(x, y, turn, i);

        gamePane.getChildren().add(i);
        attachedstone.add(stone);
        i.setVisible(true);

//        방금 논 돌 옆에 돌이 있으면 무슨색인지 체크
//        다른 색이면 왼쪽으로 한 번 더 돌 있는지 체크
//        같은 색이면 방금 전에 체크한 돌 이미지 바꾸기
//

    }

    public void check(int x, int y, boolean turn) {
        int a = 1;
        boolean flag = true;
        boolean found = true;
        boolean canChange = false;
        System.out.println(attachedstone.size());
        ArrayList<Stone> stonesToChange = new ArrayList<>();
        while (flag) {
            try {
                for (int j = 0; j < attachedstone.size() - 1; j++) {
                    if ((x / 50 - a == attachedstone.get(j).getX() / 50) && (y / 50 == attachedstone.get(j).getY() / 50)){
                        if (turn != attachedstone.get(j).isTurn()) { //다른색이면
                            a++;
                            stonesToChange.add(attachedstone.get(j));
                        } else if(turn == attachedstone.get(j).isTurn()){ //같은색이면
                            flag = false;
                            canChange = true;
                        }
                    } else {
                        System.out.print("turning flag to false.");
                        flag = false;
                    }
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
            }
        }
        if(canChange) {
            stonesToChange.forEach(stone -> {
                stone.getImageview().setImage(turn ? white_image : black_image);
            });
        }
//        while (flag) {
//            for (int j = 0; j < attachedstone.size() - 1; j++) {
//                if ((x / 50 - a == attachedstone.get(j).getX() / 50) && (y / 50 == attachedstone.get(j).getY() / 50)) { //바로 옆에 돌이 있는지 체크
//
//                    if (turn != attachedstone.get(j).isTurn()) { //다른색이면
//                        a++;
//                        j--;
//                        break;
//                    } else {
//                        flag = false;
//                    }
//                    if (turn == attachedstone.get(j).isTurn()) {
//                        System.out.println("다른 색");
//                        attachedstone.get(j - 1).imageview.setImage(black_image);
//                    } else {
//                        attachedstone.get(j - 1).imageview.setImage(white_image);
//                    }
//
//                    System.out.println("있음");
//                } else {
//                    System.out.println("없음");
//                }
//
//            }
//        }
    }

    class RulePrint extends Thread {


        @Override
        public void run() {
            Label rule1 = new Label();
            Label rule2 = new Label();
            Label rule3 = new Label();
            Label rule4 = new Label();
            Label rule5 = new Label();

            rule1.setText("바둑은 줄과 줄이 교차되는 지점에 돌을 두지만, 오델로는 칸 안에 돌을 둔다.\n");
            rule1.setLayoutX(230);
            rule1.setLayoutY(150);
            Platform.runLater(() -> {
                Rule.getChildren().add(rule1);
            });

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            rule2.setText("처음에는 정 중앙에 흑백 2개의 돌을 교차로 놓고 게임을 시작한다.\n");
            rule2.setLayoutX(250);
            rule2.setLayoutY(180);
            Platform.runLater(() -> {
                Rule.getChildren().add(rule2);
            });

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            rule3.setText("돌을 놓을 때, 자신이 놓을 돌과 자신의 돌 사이에 상대편의 돌이 있어야 돌을 놓을 수 있으며\n");
            rule3.setLayoutX(200);
            rule3.setLayoutY(210);
            Platform.runLater(() -> {
                Rule.getChildren().add(rule3);
            });

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            rule4.setText("돌을 놓게 되면, 상대편의 돌을 뒤집어 자기편의 돌로 만들 수 있다.\n");
            rule4.setLayoutX(240);
            rule4.setLayoutY(240);
            Platform.runLater(() -> {
                Rule.getChildren().add(rule4);
            });

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            rule5.setText("흑과 백 모두 돌을 놓을 곳이 없으면 게임이 끝나고, 돌이 더 많은 쪽이 승리하게 된다.\n");
            rule5.setLayoutX(215);
            rule5.setLayoutY(270);
            Platform.runLater(() -> {
                Rule.getChildren().add(rule5);
            });
        }

    }

}










